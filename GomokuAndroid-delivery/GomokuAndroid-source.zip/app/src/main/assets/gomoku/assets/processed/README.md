# Processed Asset Notes

Phase 1 uses the supplied JPG assets directly where possible.

- `home-background.jpg`: full-screen home background.
- `game-background-board.jpg`: full-screen gameplay background with baked board art.
- `avatar-black.jpg` and `avatar-white.jpg`: circular avatar images via CSS clipping.
- `player-black-plate.jpg` and `player-white-plate.jpg`: used as decorative plate backgrounds with CSS masking by overflow.
- `bottom-buttons.jpg`: visual reference only in Phase 1; buttons are recreated in CSS to avoid checkerboard artifacts.
- `victory-title-transparent.png`: transparent win-title asset generated from `victory-title.jpg` to remove the baked checkerboard background.
- `dialog-frame.jpg`: visual reference for CSS dialog framing in Phase 1.
- `board-frame.jpg`: reserved for a later board-frame replacement if the gameplay background board cannot align cleanly.
