# 五子棋 Android 课程作业

这是一个 Kotlin Android Studio 工程。应用使用原生 `WebView` 加载 APK 内置的 H5 五子棋页面，游戏资源全部在 `app/src/main/assets/gomoku/` 中，不依赖网页服务器。

## 运行方式

1. 用 Android Studio 打开本目录 `GomokuAndroid`。
2. 等待 Gradle 首次同步完成。首次同步需要能够访问 Google Maven、Maven Central 和 Gradle Plugin Portal。
3. 连接 Android 手机并开启 USB 调试，或创建模拟器。
4. 点击 Android Studio 顶部的运行按钮，即可安装和启动。

## 生成 APK

在 Android Studio 中选择 `Build > Build APK(s)`，调试安装包会生成在：

`app/build/outputs/apk/debug/app-debug.apk`

也可在终端执行：

```powershell
$env:JAVA_HOME = 'D:\Android studio\jbr'
.\gradlew.bat assembleDebug
```

## 目录说明

- `app/src/main/java/com/example/gomokuandroid/MainActivity.kt`：Kotlin 原生入口，配置 WebView。
- `app/src/main/res/layout/activity_main.xml`：全屏游戏容器。
- `app/src/main/assets/gomoku/`：内置 H5 页面、棋盘背景、头像和弹窗图片。
- `app/src/main/AndroidManifest.xml`：应用入口与竖屏配置。

## 提交前填写

请在 Android Studio 中将下列信息换成课程要求内容：

- 包名：默认 `com.example.gomokuandroid`。
- 应用名：当前为“`五子棋`”。
- 项目作者、学号、班级：如课程要求写入封面或说明文档，请按实际信息补充。

## 当前功能

- 本地双人五子棋对局。
- 首落预览、再次点击确认落子。
- 当前行棋方状态和顶部玩家卡片高亮。
- 悔棋、重玩、设置、退出确认。
- 五连高亮、胜利弹窗与平局提示。
- 本地化图片资源和落子音效。
