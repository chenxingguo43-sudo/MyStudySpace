# 五子棋 H5 交付说明

## 运行方式

在项目根目录启动静态服务器：

```powershell
node server.js
```

浏览器打开：`http://localhost:3000/gomoku-h5/index.html`。

## 已实现功能

- 15 x 15 五子棋棋盘，本地双人轮流落子。
- 横、竖、两条斜线五连胜负判断，以及棋盘满后的平局提示。
- 当前回合文字提示和玩家卡片高亮。
- 五连棋子金色描边与连线高亮，胜利弹窗。
- 悔棋、重玩、离开确认、规则和声音设置。
- 可选二次确认：第一次点击显示半透明预落子，再点击同一交叉点才正式落子；点击其他空位可移动候选位置。
- 落子、悔棋、重玩、胜利音效与轻量振动反馈。

## 交付文件

- `index.html`: 游戏入口与全部 HTML、CSS、JavaScript。
- `assets/`: 页面背景、头像、胜利标题等本地素材，必须和 `index.html` 一起保留。
- `README.md`: 本说明。

## Android Kotlin 接入

课程作业如需 Android Studio/Kotlin 外壳，可将本目录的 `index.html` 和 `assets/` 复制到 Android 项目的 `app/src/main/assets/gomoku/`，再通过 `WebView` 加载：

```kotlin
webView.settings.javaScriptEnabled = true
webView.loadUrl("file:///android_asset/gomoku/index.html")
```

H5 负责界面、棋盘和规则；Kotlin 只负责 WebView 容器、应用图标和 Android 打包。
